import { crystalize } from './crystalize'
import { liquidify } from './liquidify'

export const effects = {
  crystalize,
  liquidify,
}
