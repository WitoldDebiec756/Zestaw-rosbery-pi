package de.caluga.ecc;

import java.security.SecureRandom;

public class Rand {
    public static final SecureRandom om = new SecureRandom();
}
