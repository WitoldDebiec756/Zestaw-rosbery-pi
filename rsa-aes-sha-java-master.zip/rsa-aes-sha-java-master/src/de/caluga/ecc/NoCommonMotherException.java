package de.caluga.ecc;

public class NoCommonMotherException extends Exception {

    public String getErrorString() {
        return "NoCommonMother";
    }

}
