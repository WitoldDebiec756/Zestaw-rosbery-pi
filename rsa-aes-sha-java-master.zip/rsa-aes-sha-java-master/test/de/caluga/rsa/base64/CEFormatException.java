/*
 * %W% %E%
 *
 * Copyright (c) 2006, Oracle and/or its affiliates. All rights reserved.
 * ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package de.caluga.rsa.base64;

import java.io.IOException;

public class CEFormatException extends IOException {
    public CEFormatException(String s) {
        super(s);
    }
}
