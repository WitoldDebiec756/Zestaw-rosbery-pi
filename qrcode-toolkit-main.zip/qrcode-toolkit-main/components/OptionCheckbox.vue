<script setup lang="ts">
const value = defineModel<boolean>('modelValue', {
  type: Boolean,
})
</script>

<template>
  <div border="~ base rounded" flex="~ gap-2 items-center" relative h-5 w-5 p0.5 icon-button>
    <div i-ri-check-line :class="value ? '' : 'op0'" />
    <input v-model="value" type="checkbox" absolute inset-0 z-10 opacity-0.1>
  </div>
</template>
